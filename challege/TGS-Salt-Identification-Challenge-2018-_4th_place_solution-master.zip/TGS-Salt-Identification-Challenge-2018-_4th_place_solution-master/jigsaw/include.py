import argparse
import cv2
import os
import numpy as np
import json
import pandas as pd
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import gc
from sklearn.neighbors import KDTree
import networkx as nx

# add your path here
root_dir = r'/data1/shentao/DATA/Kaggle/Salt/Kaggle_salt'